package com.example.SpringWithRabbitMQ;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWithRabbitMqApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWithRabbitMqApplication.class, args);
	}

}
